insert into empleado (numemp, nombre) values (44, 'prueba');

select * from empleado
where numemp = 44;

delete from empleado where numemp = 44;